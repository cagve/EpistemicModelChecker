package org.interfazfx;

import javax.swing.*;

public class Launcher {
    public  static void main (String[]args){
        App.main(args);
    }

}
